TERMIN TRACKER POCKET 0.3 — KNULLI ARM64

Copy TerminPocket.sh, TerminPocket.png and terminpocket/ to SHARE/roms/ports/.
On upgrades, keep your existing projects and controls-v2.txt.
Create a folder named Sample Set in terminpocket/ and add your own WAV samples.
No sample pack or recordings are included.

Select opens pages; Start plays/stops; D-pad navigates; A confirms; B goes back.
L2+A enables REC; R2 opens Pattern Actions; X loads WAV in Instrument/Sampler/Granular.
Y auditions; L1/R1 selects track (or FX tabs on FX page).
